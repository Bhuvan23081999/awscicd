package com.cts.pipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwscicdApplicationTests {

	@Test
	void contextLoads() {
	}

}
