package com.cts.pipeline.model;

public class Product {

}
