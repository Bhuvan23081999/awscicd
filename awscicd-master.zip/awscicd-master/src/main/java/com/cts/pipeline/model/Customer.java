package com.cts.pipeline.model;

public class Customer {

}
