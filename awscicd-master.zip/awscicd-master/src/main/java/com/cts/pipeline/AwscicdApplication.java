package com.cts.pipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwscicdApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwscicdApplication.class, args);
	}

}
